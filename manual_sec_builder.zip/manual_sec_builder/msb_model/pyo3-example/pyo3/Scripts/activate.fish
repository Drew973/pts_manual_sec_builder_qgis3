# This file must be used using `source bin/activate.fish` *within a running fish ( http://fishshell.com ) session*.
# Do not run it directly.

function deactivate -d 'Exit virtualenv mode and return to the normal environment.'
    # reset old environment variables
    if test -n "$_OLD_VIRTUAL_PATH"
        set -gx PATH $_OLD_VIRTUAL_PATH
        set -e _OLD_VIRTUAL_PATH
    end

    if test -n ''
      if test -n "$_OLD_VIRTUAL_TCL_LIBRARY";
        set -gx TCL_LIBRARY "$_OLD_VIRTUAL_TCL_LIBRARY";
        set -e _OLD_VIRTUAL_TCL_LIBRARY;
      else;
        set -e TCL_LIBRARY;
      end
    end
    if test -n ''
      if test -n "$_OLD_VIRTUAL_TK_LIBRARY";
        set -gx TK_LIBRARY "$_OLD_VIRTUAL_TK_LIBRARY";
        set -e _OLD_VIRTUAL_TK_LIBRARY;
      else;
        set -e TK_LIBRARY;
      end
    end

    if test -n "$_OLD_PKG_CONFIG_PATH"
        set -gx PKG_CONFIG_PATH "$_OLD_PKG_CONFIG_PATH"
        set -e _OLD_PKG_CONFIG_PATH
    end

    if test -n "$_OLD_VIRTUAL_PYTHONHOME"
        set -gx PYTHONHOME "$_OLD_VIRTUAL_PYTHONHOME"
        set -e _OLD_VIRTUAL_PYTHONHOME
    end

    if test -n "$_OLD_FISH_PROMPT_OVERRIDE"
       and builtin functions -q _old_fish_prompt
        # Set an empty local `$fish_function_path` to allow the removal of `fish_prompt` using `functions -e`.
        set -l fish_function_path

        # Erase virtualenv's `fish_prompt` and restore the original.
        builtin functions -e fish_prompt
        builtin functions -c _old_fish_prompt fish_prompt
        builtin functions -e _old_fish_prompt
        set -e _OLD_FISH_PROMPT_OVERRIDE
    end

    set -e VIRTUAL_ENV
    set -e VIRTUAL_ENV_PROMPT

    if test "$argv[1]" != 'nondestructive'
        # Self-destruct!
        builtin functions -e pydoc
        builtin functions -e deactivate
    end
end

# Unset irrelevant variables.
deactivate nondestructive

set -gx VIRTUAL_ENV 'C:\Users\drew.bennett\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\manual_sec_builder\msb_model\pyo3-example\pyo3'
if string match -qr 'CYGWIN|MSYS|MINGW' (uname)
    set -gx VIRTUAL_ENV (cygpath -u $VIRTUAL_ENV)
end

set -gx _OLD_PKG_CONFIG_PATH "$PKG_CONFIG_PATH"
set -gx PKG_CONFIG_PATH "$VIRTUAL_ENV/lib/pkgconfig:$PKG_CONFIG_PATH"

set -gx _OLD_VIRTUAL_PATH $PATH
set -gx PATH "$VIRTUAL_ENV"'/'Scripts $PATH

if test -n ''
  if set -q TCL_LIBRARY;
    set -gx _OLD_VIRTUAL_TCL_LIBRARY $TCL_LIBRARY;
  end
  set -gx TCL_LIBRARY ''''
end
if test -n ''
  if set -q TK_LIBRARY;
    set -gx _OLD_VIRTUAL_TK_LIBRARY $TK_LIBRARY;
  end
  set -gx TK_LIBRARY ''''
end

# Prompt override provided?
# If not, just use the environment name.
if test -n ''
    set -gx VIRTUAL_ENV_PROMPT ''
else
    set -gx VIRTUAL_ENV_PROMPT (basename "$VIRTUAL_ENV")
end

# Unset `$PYTHONHOME` if set.
if set -q PYTHONHOME
    set -gx _OLD_VIRTUAL_PYTHONHOME $PYTHONHOME
    set -e PYTHONHOME
end

function pydoc
    python -m pydoc $argv
end

if test -z "$VIRTUAL_ENV_DISABLE_PROMPT"
    # Copy the current `fish_prompt` function as `_old_fish_prompt`.
    builtin functions -c fish_prompt _old_fish_prompt

    # Route every builtin the prompt path uses through `builtin` so a user function that shadows
    # `printf`, `string`, `echo`, or `source`/`.` cannot hijack the prompt (Issue #93858 follow-up,
    # CPython gh-140006). A dot-style directory navigator redefining `.` is the common trigger.
    function fish_prompt
        set -l old_status $status
        # Run the user's prompt first; it might depend on (pipe)status.
        set -l prompt (_old_fish_prompt)

        builtin printf '(%s) ' $VIRTUAL_ENV_PROMPT

        builtin string join -- \n $prompt # handle multi-line prompts
        builtin echo "exit $old_status" | builtin source -
    end

    set -gx _OLD_FISH_PROMPT_OVERRIDE "$VIRTUAL_ENV"
end
