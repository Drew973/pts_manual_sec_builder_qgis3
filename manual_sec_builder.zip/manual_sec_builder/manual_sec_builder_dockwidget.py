import os
from os import path

from PyQt5 import QtGui

from PyQt5.Qt import QItemSelectionModel
                      
from qgis.PyQt import uic
from qgis.PyQt.QtCore import pyqtSignal,QSettings,Qt,QUrl
from qgis.utils import iface
from qgis.core import QgsFieldProxyModel
from qgis.PyQt.QtWidgets import QDockWidget,QFileDialog,QMessageBox,QMenuBar,QMenu
from qgis.PyQt.QtGui import QKeySequence

from manual_sec_builder.widgets.makeRteDialog import makeRteDialog
from manual_sec_builder.msb_model import msb_model,layer_functions

from manual_sec_builder.save_scanner_rte_dialog import saveScannerRteDialog


from qgis.core import QgsMapLayerProxyModel

from .resources import qt_resource_data# icon not shown without runnng resorces.py. why?

def fixHeaders(path):
    with open(path) as f:
        t = f.read()

    r = {'qgsfieldcombobox.h':'qgis.gui','qgsmaplayercombobox.h':'qgis.gui'}
    for i in r:
        t = t.replace(i,r[i])

    with open(path, "w") as f:
        f.write(t)


VERSION = 3.3

uiPath = os.path.join(os.path.dirname(__file__), 'manual_sec_builder_dockwidget_base.ui')
fixHeaders(uiPath)
FORM_CLASS, _ = uic.loadUiType(uiPath)


SEC_FILTER = 'sec file(*.sec)'
SR_FILTER = 'sr file(*.sr)'
TRACS_RTE_FILTER  = 'TRACS rte(*.rte)'
SCANNER_RTE_FILTER = 'SCANNER rte(*.rte)'




class manual_sec_builderDockWidget(QDockWidget, FORM_CLASS):

    closingPlugin = pyqtSignal()

    def __init__(self, parent = None):
        super(manual_sec_builderDockWidget, self).__init__(parent)
        self.setupUi(self)
        self.setWindowTitle('manual sec builder {v}'.format(v = VERSION))
        self.model = msb_model.msbModel(self)
        
        self.rteDialog = makeRteDialog(parent = self , model = self.model , layerBox = self.layerBox)#persistant.
        
        self.saveScannerRteDialog = saveScannerRteDialog(parent = self , model = self.model)#persistant.
        
        
        self.sectionBox.setFilters(QgsFieldProxyModel.String)
        self.sectionBox.activated.connect(self.labelFieldSet)
        
        self.layerBox.setFilters(QgsMapLayerProxyModel.LineLayer)
        self.layerBox.setAllowEmptyLayer(True)
        self.layerBox.layerChanged.connect(self.layerChange)
        
        layer = QSettings('pts', 'msb').value('layer','',str)
        self.layerBox.setCurrentIndex(self.layerBox.findText(layer))#try to set to last value 
        self.layerChange(self.layerBox.currentLayer())
        
        self.initTopMenu()
        self.initTableMenu()
        
       # self.rteDialog.buttonBox.accepted.connect(self.saveAsRte)
        #self.rteDialog.buttonBox.accepted.connect(self.rteDialog.hide)

        self.tableView.setModel(self.model)
        initDragAndDrop(self.tableView)

        self.model.countChanged.connect(self.rowCountChanged)





    def openFile(self , clear: bool = False):
        if clear:
            row = None
            cap = 'load route file'
        else:
            row = self.rowBox.value()
            cap = 'insert route file'
                
                
        filt = ';;'.join([SEC_FILTER,SR_FILTER,TRACS_RTE_FILTER,SCANNER_RTE_FILTER])
        p , ext = QFileDialog.getOpenFileName(caption = cap , filter = filt , directory = self.lastFolder())
        
        if p:
            self.setFolder(p)

            
            if ext == SEC_FILTER:
                #use direction from 'reversed' box
                with open(p,'r') as f:
                    self.model.loadSec(f = f,rev = self.rev() , row = row)
 
            if ext == SR_FILTER:
                with open(p,'r') as f:
                    self.model.loadSr(f,row)

            if ext == TRACS_RTE_FILTER:
                #leave reversed column blank
                with open(p,'r') as f:
                    self.model.loadRte(f = f,row = None)
                    iface.messageBar().pushMessage("manual secbuilder:loaded "+p,duration = 4)  
                
            if ext == SCANNER_RTE_FILTER:
                #leave reversed column blank
                self.model.loadScannerRte(p)

        #iface.messageBar().pushMessage("manual secbuilder:inserted "+p,duration = 4)                    



    def layerChange(self,layer):
        self.sectionBox.setLayer(layer)
        sf = QSettings('pts', 'msb').value('sectionField','',str)
        self.sectionBox.setCurrentIndex(self.sectionBox.findText(sf))

    
    #saves setting for label field when user activates box.
    #i:int
    def labelFieldSet(self,i):
        sf = self.sectionBox.currentField()
        if sf:
            QSettings('pts', 'msb').setValue('sectionField',sf)

        
    #row = row number
    def addRow(self,label,isReversed = None,rowNumber = None):
        self.model.addRow(label,isReversed,rowNumber)


    def rowCountChanged(self,change):
        newCount = self.model.rowCount() 
        v = self.rowBox.value()+change
        self.rowBox.setMaximum(newCount+1)
        self.rowBox.setValue(v)


    #for requested view
    def initTableMenu(self):
        self.tableMenu = QMenu()
        from_layer_act = self.tableMenu.addAction('set selected from layer')
        from_layer_act.triggered.connect(self.selectedFromFeatures)

        zoomAct = self.tableMenu.addAction('select on layer')
        zoomAct.triggered.connect(self.selectOnLayer)

        delAct = self.tableMenu.addAction('delete selected rows')
        delAct.triggered.connect(lambda:dropSelectedRows(self.tableView))

        delAllAct = self.tableMenu.addAction('delete all rows')
        delAllAct.triggered.connect(self.removeAll)        
        
        self.tableView.setContextMenuPolicy(Qt.CustomContextMenu);
        self.tableView.customContextMenuRequested.connect(lambda pt:self.tableMenu.exec_(self.tableView.mapToGlobal(pt)))


    def addDummy(self):
        self.model.addDummy(row = self.rowBox.value())


    #add selected feature of layer
    def addFeature(self):

        layer = self.getLayer()
        field = self.getLabelField()
        
        if layer and field:
            
            sf = layer.selectedFeatures()
            
            if len(sf)>1:
                iface.messageBar().pushMessage("manual sec builder: >1 feature selected",duration = 4)
                return

            if len(sf)<1:
                iface.messageBar().pushMessage("manual secbuilder: no features selected.",duration = 4)
                return

            sec = sf[0][field]
            self.addRow(label = sec,isReversed = self.rev(),rowNumber = self.rowBox.value()-1)
                
                


#reversed selected?
    def rev(self):
        return self.model.revToBool(self.reversedBox.currentText())
                
                
    def lastFolder(self):
        folder = QSettings('pts', 'msb').value('folder','',str)
        if folder:
            return folder
        else:
            return path.expanduser('~\\Documents')


    def setFolder(self,p):
        f = path.dirname(p)
        QSettings('pts', 'msb').setValue('folder',f)


        
    def removeAll(self):
        response = QMessageBox.question(self,'remove all','remove all sections from table?',QMessageBox.Yes | QMessageBox.No)
        if response ==  QMessageBox.Yes:
            self.model.clear()


    def saveAsSec(self):
        p = QFileDialog.getSaveFileName(self, 'Save File',filter = SEC_FILTER,directory = self.lastFolder())[0]
        if p:

            if self.model.rowCount() == 0:
                iface.messageBar().pushMessage("manual secbuilder:no sections to save:",duration = 4)
                return
            
            self.setFolder(p)

            with open(p,'w') as f:
                self.model.saveSec(f = f)

            iface.messageBar().pushMessage("manual secbuilder:saved sec:"+p,duration = 4)


    #list of features   
    def features(self):
        layer = self.getLayer()
        labelField = self.getLabelField()
        if layer and labelField:
            return[layer_functions.getFeature(layer,labelField,val) for val in self.model.sectionLabels()]




    def saveAsSr(self):
        p = QFileDialog.getSaveFileName(self, 'Save File' , filter = SR_FILTER , directory = self.lastFolder())[0]
        if p:
            if self.model.rowCount() == 0:
                iface.messageBar().pushMessage("manual secbuilder:no sections to save:",duration = 4)
                return
            
            self.setFolder(p)

            with open(p,'w') as f:
                self.model.saveSr(f,header = True)
                                      
            iface.messageBar().pushMessage("manual secbuilder:saved .sr:"+p,duration = 4)
                

        
    def closeEvent(self, event):
        self.closingPlugin.emit()
        event.accept()


    def getLayer(self):
        layer = self.layerBox.currentLayer()
        if layer:
            return layer
        else:
            iface.messageBar().pushMessage("manual secbuilder: no layer selected",duration = 4)


    def getLabelField(self):
        field = self.sectionBox.currentField()
        if field:
            return field
        else:
            iface.messageBar().pushMessage("manual secbuilder: section field not set.",duration = 4)

    
    def selectOnLayer(self):
        layer = self.getLayer()
        field = self.getLabelField()       
        sections = [self.model.item(row,0).data(Qt.EditRole) for row in selectedRows(self.tableView)]#selected sections

        if layer and field:
            layer_functions.selectValues(layer,field,sections)


    def initTopMenu(self):
        topMenu = QMenuBar()       

        #load#####################
        fileMenu = topMenu.addMenu("File")
  
        openAct = fileMenu.addAction('Open...')
        openAct.triggered.connect(lambda: self.openFile(clear = True))

        #insert#################
        insertMenu = topMenu.addMenu("Insert")
        insertMenu.setToolTipsVisible(True)
        
        insertFileAct = insertMenu.addAction('Insert file...')
        insertFileAct.triggered.connect(lambda: self.openFile(clear = False))
        insertFileAct.setToolTip('Insert file at selected row')

        self.addFeatureAct = insertMenu.addAction('Add Selected Feature')
        self.addFeatureAct.setShortcut(QKeySequence('Alt+1'))#focus policy of dockwidget probably important here
        self.addFeatureAct.triggered.connect(self.addFeature)
        self.addFeatureAct.setToolTip('Insert selected feature of layer using selected row and direction')

        self.addDummyAct = insertMenu.addAction('Add Dummy')
        self.addDummyAct.setShortcut(QKeySequence('Alt+2'))#focus policy of dockwidget probably important here
        self.addDummyAct.triggered.connect(self.addDummy)
        self.addDummyAct.setToolTip('Insert dummy at row')

        #save###########################################save
        saveMenu = fileMenu.addMenu("Save")
        
        saveSrAct = saveMenu.addAction('Save as .sr...')
        saveSrAct.triggered.connect(self.saveAsSr)

        saveSecAct = saveMenu.addAction('Save as .sec...')
        saveSecAct.triggered.connect(self.saveAsSec)

        saveRteAct = saveMenu.addAction('Save as TRACS .rte...')
        saveRteAct.triggered.connect(self.rteDialog.show)
        
        saveScannerRteAct = saveMenu.addAction('Save as SCANNER .rte...')
        saveScannerRteAct.triggered.connect(self.saveScannerRte)
        
        
        #help######################help

        helpMenu = topMenu.addMenu('Help')  
        openHelpAct = helpMenu.addAction('Open help (in your default web browser)')
        openHelpAct.triggered.connect(self.openHelp)

        
        self.main_widget.layout().setMenuBar(topMenu)


    def saveScannerRte(self):
        self.saveScannerRteDialog.show()



#opens help/index.html in default browser
    def openHelp(self):
        helpPath = os.path.join(os.path.dirname(__file__),'help','overview.html')
        helpPath = 'file:///'+os.path.abspath(helpPath)
        QtGui.QDesktopServices.openUrl(QUrl(helpPath))

        

#select rows matching selected features of layer
    def selectedFromFeatures(self):
        layer = self.getLayer()
        field = self.getLabelField()
        
        if layer and field:
            sections = [f[field] for f in layer.selectedFeatures()]
            selectRowsFromValues(tableView = self.tableView,column = 0,values = sections)
            


def dropSelectedRows(tableView):
    model = tableView.model()
    rows = [r.row() for r in tableView.selectionModel().selectedRows()]#selectedRows() returns list of indexes
    for r in sorted(rows,reverse = True):
        model.takeRow(r)


def selectedRows(tableView):
    return [r.row() for r in tableView.selectionModel().selectedRows()]


#select rows where column matches values
def selectRowsFromValues(tableView,column,values,clearSelection = True):
    model = tableView.model()
    
    items = []
    for v in values:
        items += model.findItems(v,column = column)
    
    indexes = [i.index() for i in items]

    for c in range(model.columnCount()):
        indexes +=  [i.siblingAtColumn(c) for i in indexes]#add indexes for second column
    
    
    tableView.selectionModel().clearSelection()
    for i in indexes:
        tableView.selectionModel().select(i,QItemSelectionModel.Select)



def initDragAndDrop(tableView):
    tableView.setSelectionBehavior(tableView.SelectRows)
    tableView.setDragDropMode(tableView.InternalMove)
    tableView.setDragDropOverwriteMode(False)


#unused
#select row where column = value
#def selectRowFromValue(tableView,column,value):
    #rows = [i.index().row() for i in tableView.model().findItems(value,column = column)]
